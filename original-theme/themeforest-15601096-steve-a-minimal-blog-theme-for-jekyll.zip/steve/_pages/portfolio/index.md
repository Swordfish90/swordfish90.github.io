---
layout: page
title:  "Portfolio"
permalink: "/portfolio/"
---

<figure>
    <img src="https://cdn.dribbble.com/users/1073937/screenshots/5036567/waterfall.png" />
    <figcaption>Created by <a href="https://dribbble.com/HannahLizSharp" target="_blank_">Hannah Sharp</a></figcaption>
</figure>

In addition to writing posts, another thing you may want to do with your Jekyll site is create static pages. By taking advantage of the way Jekyll copies files and directories, this is easy to do. [More Information](https://jekyllrb.com/docs/pages/){:target="_blank"}